namespace TennisBookings.ResultsProcessing.ExternalServices.Players;

public sealed class TennisPlayerApiClientOptions
{
	public string BaseAddress { get; set; } = string.Empty;
}
