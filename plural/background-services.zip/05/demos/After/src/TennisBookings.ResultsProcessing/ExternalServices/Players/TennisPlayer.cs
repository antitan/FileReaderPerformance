namespace TennisBookings.ResultsProcessing.ExternalServices.Players;

public class TennisPlayer
{
	public int Id { get; set; }
	public string Forename { get; set; } = string.Empty;
	public string Surname { get; set; } = string.Empty;
}
