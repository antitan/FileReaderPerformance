namespace TennisBookings.ResultsProcessing.ExternalServices.Statistics;

public class PlayerStatistic
{
	public int PlayerId { get; set; }
	public int GamesWon { get; set; }
	public int GamesLost { get; set; }
}
