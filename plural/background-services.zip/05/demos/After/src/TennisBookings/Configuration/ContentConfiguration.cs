namespace TennisBookings.Configuration;

public class ContentConfiguration : IContentConfiguration
{
	public bool CheckForProfanity { get; set; }
}
