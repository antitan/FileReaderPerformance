namespace TennisBookings.Configuration;

public interface IContentConfiguration
{
	bool CheckForProfanity { get; }
}
