﻿namespace TennisBookings.Configuration;

public interface IFeaturesConfiguration
{
	bool EnableWeatherForecast { get; set; }
}
