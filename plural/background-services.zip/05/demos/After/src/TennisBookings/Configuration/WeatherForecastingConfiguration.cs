﻿namespace TennisBookings.Configuration;

public class WeatherForecastingConfiguration
{
    public bool EnableWeatherForecast { get; set; }
}
