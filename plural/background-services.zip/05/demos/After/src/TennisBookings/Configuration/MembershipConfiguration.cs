﻿namespace TennisBookings.Configuration;

public class MembershipConfiguration
{
	public decimal MonthlyMembershipFullPrice { get; set; }
}
