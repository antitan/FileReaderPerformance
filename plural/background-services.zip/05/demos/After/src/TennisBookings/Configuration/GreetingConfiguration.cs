namespace TennisBookings.Configuration;

public class GreetingConfiguration
{
	public string GreetingColour { get; set; } = "black";
}
