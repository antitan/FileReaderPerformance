namespace TennisBookings.Services.Time;

public interface ITimeService
{
	DateTime CurrentTime { get; }
}
