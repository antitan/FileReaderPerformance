namespace TennisBookings.Services.Staff;

public interface IStaffRolesOptionsService
{
	List<string> Roles { get; }
}
