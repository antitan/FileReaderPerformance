namespace TennisBookings.Data;

public class TennisBookingsRole : IdentityRole
{
}
