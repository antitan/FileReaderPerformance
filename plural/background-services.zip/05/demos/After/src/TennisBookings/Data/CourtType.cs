namespace TennisBookings.Data;

public enum CourtType
{
	Indoor,
	Outdoor
}