﻿namespace TennisBookings.Domain;

public class HourlyAvailabilityDictionary : Dictionary<int, Dictionary<int, bool>>
{

}
