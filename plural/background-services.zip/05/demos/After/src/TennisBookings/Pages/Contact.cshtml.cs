using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace TennisBookings.Pages
{
    public class ContactModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
